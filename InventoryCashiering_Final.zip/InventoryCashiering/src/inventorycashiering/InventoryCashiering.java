
package inventorycashiering;

/**
 *
 * @author 1styrGroupB
 */
public class InventoryCashiering {

    
    public static void main(String[] args) {
        new LoginPage().setVisible(true);
        
    }
    
}
